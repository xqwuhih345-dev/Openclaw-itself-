/**
 * OpenClaw Task Runner
 * ─────────────────────
 * Executes a task that was received via call.
 * Currently logs + saves the task, and acts as the extensible
 * hook for plugging in real YouTube-automation actions.
 */

const logger = require('./logger');
const store  = require('./memory/store');
const fs     = require('fs-extra');
const path   = require('path');

const TASKS_DIR = path.join(__dirname, 'tasks');

/**
 * Execute task.
 * @param {string} task       — task text from transcription
 * @param {string} purpose    — 'task1' | 'task2'
 * @param {object} mem        — current memory state
 */
async function runTask(task, purpose, mem) {
  logger.info(`[TaskRunner] Starting ${purpose}: "${task}"`);

  // ── 1. Save task to disk for audit ──────────────────────────────────────
  const dateStr = store.today();
  const taskFile = path.join(TASKS_DIR, `${dateStr}-${purpose}.txt`);
  await fs.ensureDir(TASKS_DIR);
  await fs.writeFile(taskFile, [
    `Date     : ${dateStr}`,
    `Purpose  : ${purpose}`,
    `Task     : ${task}`,
    `StartedAt: ${new Date().toISOString()}`,
  ].join('\n'), 'utf8');

  // ── 2. Execute the task ───────────────────────────────────────────────────
  //   Extend this section to run real YouTube automation, AI scripts, etc.
  //   For now we simulate work with a timed placeholder.
  logger.info(`[TaskRunner] Executing: ${task}`);
  await simulateWork(task);

  // ── 3. Mark completed in memory ──────────────────────────────────────────
  const freshMem = store.load();
  if (purpose === 'task1') {
    freshMem.dailyState.task1Completed = true;
  } else {
    freshMem.dailyState.task2Completed = true;
    freshMem.meta.totalTasksCompleted += 1;
  }
  freshMem.meta.totalTasksCompleted += 1;
  store.save(freshMem);

  // Append completion timestamp to task file
  await fs.appendFile(taskFile, `\nCompletedAt: ${new Date().toISOString()}\n`, 'utf8');

  logger.info(`[TaskRunner] ${purpose} completed ✓`);
  return true;
}

/** Placeholder — swap this out for real YouTube automation logic */
async function simulateWork(task) {
  // Simulate variable work duration (5–15 s in dev)
  const ms = process.env.NODE_ENV === 'production' ? 2000 : 5000;
  await new Promise(r => setTimeout(r, ms));
  logger.info(`[TaskRunner] Work done for: "${task.substring(0, 60)}..."`);
}

module.exports = { runTask };
