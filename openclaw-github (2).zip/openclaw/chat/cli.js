/**
 * OpenClaw CLI Chat
 * ──────────────────
 * Interactive terminal chat with OpenClaw.
 * Usage: node chat/cli.js  OR  npm run chat
 */

require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });

const readline = require('readline');
const brain    = require('../brain/ollama');
const store    = require('../memory/store');
const ltm      = require('../memory/longTerm');
const prompts  = require('../brain/prompts');

const RESET  = '\x1b[0m';
const GREEN  = '\x1b[32m';
const CYAN   = '\x1b[36m';
const YELLOW = '\x1b[33m';
const BOLD   = '\x1b[1m';
const DIM    = '\x1b[2m';

const history = [];

async function run() {
  console.log(`\n${BOLD}${GREEN}`);
  console.log('  ██████╗ ██████╗ ███████╗███╗   ██╗ ██████╗██╗      █████╗ ██╗    ██╗');
  console.log(' ██╔═══██╗██╔══██╗██╔════╝████╗  ██║██╔════╝██║     ██╔══██╗██║    ██║');
  console.log(' ██║   ██║██████╔╝█████╗  ██╔██╗ ██║██║     ██║     ███████║██║ █╗ ██║');
  console.log(' ██║   ██║██╔═══╝ ██╔══╝  ██║╚██╗██║██║     ██║     ██╔══██║██║███╗██║');
  console.log(' ╚██████╔╝██║     ███████╗██║ ╚████║╚██████╗███████╗██║  ██║╚███╔███╔╝');
  console.log('  ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝');
  console.log(`${RESET}`);
  console.log(`${DIM}  Type your message and press Enter. Type /exit to quit.${RESET}\n`);

  const mem      = store.load();
  const brainOk  = await brain.isAvailable();

  console.log(`${DIM}  Agent status: T1=${mem.dailyState.task1Completed?'✅':'❌'} T2=${mem.dailyState.task2Completed?'✅':'❌'} | Total done: ${mem.meta.totalTasksCompleted}${RESET}`);
  console.log(`${DIM}  Brain (Ollama): ${brainOk ? '✅ Online' : '❌ Offline — basic mode'}${RESET}\n`);

  const rl = readline.createInterface({
    input:  process.stdin,
    output: process.stdout,
  });

  const ask = () => {
    rl.question(`${GREEN}${BOLD}You: ${RESET}`, async (input) => {
      const text = input.trim();

      if (!text)          { return ask(); }
      if (text === '/exit' || text === '/quit') {
        console.log(`\n${DIM}Goodbye.${RESET}\n`);
        rl.close();
        process.exit(0);
      }

      // Built-in commands
      if (text === '/status') {
        const m = store.load();
        console.log(`${CYAN}OpenClaw:${RESET} Today: T1=${m.dailyState.task1Completed?'✅':'❌'} T2=${m.dailyState.task2Completed?'✅':'❌'} | Total: ${m.meta.totalTasksCompleted}\n`);
        return ask();
      }
      if (text === '/memory') {
        const stats = ltm.getStats();
        console.log(`${CYAN}OpenClaw:${RESET} Episodes: ${stats.totalEpisodes} | Insights: ${stats.totalInsights} | Reflections: ${stats.totalReflections}\n`);
        return ask();
      }
      if (text === '/history') {
        const m = store.load();
        m.history.slice(-5).forEach(h => {
          console.log(`  ${DIM}${h.date}: T1=${h.task1Completed?'✅':'❌'} "${(h.task1||'—').substring(0,40)}"${RESET}`);
        });
        console.log('');
        return ask();
      }
      if (text === '/help') {
        console.log(`${DIM}  Commands: /status /memory /history /help /exit${RESET}\n`);
        return ask();
      }

      process.stdout.write(`${CYAN}OpenClaw: ${RESET}${DIM}thinking…${RESET}`);

      let reply = '';

      try {
        if (brainOk) {
          const mem2     = store.load();
          const ltmCtx   = await ltm.getContextSummary(text, 300);
          const agentCtx = `Today T1=${mem2.dailyState.task1Completed} T2=${mem2.dailyState.task2Completed}. Total: ${mem2.meta.totalTasksCompleted}.`;
          const context  = `${agentCtx}\nMemory: ${ltmCtx || 'none'}`;

          const messages = [
            { role: 'system', content: prompts.chat(text, context, history.slice(-6)) },
            ...history.slice(-6),
            { role: 'user', content: text },
          ];
          reply = await brain.chat(messages);
        } else {
          const m = store.load();
          const lower = text.toLowerCase();
          if (lower.includes('status'))  reply = `T1=${m.dailyState.task1Completed} T2=${m.dailyState.task2Completed}, total=${m.meta.totalTasksCompleted}`;
          else reply = 'Ollama is offline. Use /status, /memory, /history for basic info.';
        }
      } catch (e) {
        reply = `Error: ${e.message}`;
      }

      process.stdout.write('\r' + ' '.repeat(30) + '\r');
      console.log(`${CYAN}${BOLD}OpenClaw:${RESET} ${reply}\n`);

      history.push({ role: 'user', content: text });
      history.push({ role: 'assistant', content: reply });

      ask();
    });
  };

  ask();
}

run().catch(e => { console.error('Chat error:', e.message); process.exit(1); });
