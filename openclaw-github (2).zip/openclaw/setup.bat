@echo off
:: ─────────────────────────────────────────────────────────────
::  OpenClaw v2.0 — Windows Setup & Run (Command Prompt)
::  Usage:  setup.bat [mock] [chat] [brain-test]
:: ─────────────────────────────────────────────────────────────

setlocal EnableDelayedExpansion
title OpenClaw v2.0

set MODE=run
if "%1"=="mock"       set MODE=mock
if "%1"=="chat"       set MODE=chat
if "%1"=="brain-test" set MODE=brain

echo.
echo  ██████╗ ██████╗ ███████╗███╗   ██╗ ██████╗██╗      █████╗ ██╗    ██╗
echo ██╔═══██╗██╔══██╗██╔════╝████╗  ██║██╔════╝██║     ██╔══██╗██║    ██║
echo ██║   ██║██████╔╝█████╗  ██╔██╗ ██║██║     ██║     ███████║██║ █╗ ██║
echo ██║   ██║██╔═══╝ ██╔══╝  ██║╚██╗██║██║     ██║     ██╔══██║██║███╗██║
echo ╚██████╔╝██║     ███████╗██║ ╚████║╚██████╗███████╗██║  ██║╚███╔███╔╝
echo  ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝
echo  v2.0 -- Ollama Brain . Memory . Proactive . Self-Improving . Browser . Chat
echo.

:: ── 1. Check Node.js ─────────────────────────────────────────
echo [1/5] Checking Node.js...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo   [ERROR] Node.js not found.
    echo   Download from: https://nodejs.org ^(v18+ recommended^)
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node -v') do set NODE_VER=%%v
echo   [OK] Node.js !NODE_VER!

:: ── 2. Install dependencies ───────────────────────────────────
echo [2/5] Installing dependencies...
call npm install --silent
if %errorlevel% neq 0 (
    echo   [ERROR] npm install failed.
    pause
    exit /b 1
)
echo   [OK] Dependencies installed

:: ── 3. Check .env ─────────────────────────────────────────────
echo [3/5] Checking .env configuration...
if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo   [WARN] .env created from .env.example -- please fill in your credentials
    ) else (
        echo   [ERROR] .env file not found!
        pause
        exit /b 1
    )
)

:: Check for placeholder values
set MISSING=0
for %%K in (TWILIO_ACCOUNT_SID TWILIO_AUTH_TOKEN TWILIO_PHONE_NUMBER TASK_PHONE_NUMBER WEBHOOK_BASE_URL) do (
    findstr /b "%%K=your_" .env >nul 2>&1 && (
        echo   [ERROR] Placeholder not filled: %%K
        set /a MISSING+=1
    ) || (
        findstr /b "%%K=" .env >nul 2>&1 && (
            echo   [OK] %%K
        ) || (
            echo   [ERROR] Missing: %%K
            set /a MISSING+=1
        )
    )
)

if !MISSING! gtr 0 (
    echo.
    echo   Fix the above .env values then re-run setup.bat
    pause
    exit /b 1
)

:: ── 4. Check Ollama (optional) ────────────────────────────────
echo [4/5] Checking Ollama brain ^(optional^)...
curl -sf http://localhost:11434/api/tags >nul 2>&1
if %errorlevel% equ 0 (
    echo   [OK] Ollama is online
) else (
    echo   [WARN] Ollama not running -- start with: ollama serve
    echo          Download: https://ollama.com
)

:: ── 5. Watchdog health check ──────────────────────────────────
echo [5/5] Running health check...
node watchdog\watchdog.js
echo.

echo ════════════════════════════════════════
echo   OpenClaw v2.0 Ready!
echo ════════════════════════════════════════
echo.
echo   Chat UI:  http://localhost:3742/chat
echo   CLI chat: npm run chat
echo   Health:   npm run health
echo.

if "%MODE%"=="mock" (
    echo   Running in MOCK MODE ^(no real calls^)
    set MOCK_MODE=true
    node index.js
) else if "%MODE%"=="chat" (
    node chat\cli.js
) else if "%MODE%"=="brain" (
    node brain\test.js
) else (
    node index.js
)

endlocal
