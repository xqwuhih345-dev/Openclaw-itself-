/**
 * ████████████████████████████████████████████████████
 *   OpenClaw v2.0 — Autonomous Task Agent
 * ████████████████████████████████████████████████████
 *
 * Stack:
 *   🧠 Ollama        — local LLM brain
 *   🗄  Memory        — short-term (daily) + long-term (episodic)
 *   🤖 Proactive     — self-monitoring, alerts, pre-warming
 *   🔄 Self-Improve  — reflection, pattern learning, auto-tuning
 *   🌐 Browser       — headless Puppeteer web automation
 *   📧 Mail          — send task reports and summaries
 *   ⚙️  Workflow      — chainable multi-step automations
 *   🔒 Security      — encryption, audit log, rate limiting
 *   💬 Chat          — web UI + CLI + WebSocket
 *
 * Flow:
 *   1. Security check + watchdog health check + auto-repair
 *   2. Start webhook server (Twilio transcriptions)
 *   3. Start chat server (web UI on :3742)
 *   4. Start proactive agent (monitoring)
 *   5. Start self-improvement loop (daily/weekly reflections)
 *   6. Restore in-progress state from memory
 *   7. Schedule 9 AM daily call → Task 1 → Task 2
 *   8. Heartbeat every 5 min
 */

require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const cron      = require('node-cron');
const store     = require('./memory/store');
const ltm       = require('./memory/longTerm');
const logger    = require('./logger');
const caller    = require('./caller');
const runner    = require('./taskRunner');
const brain     = require('./brain/ollama');
const proactive = require('./agent/proactive');
const improve   = require('./agent/selfImprove');
const workflow  = require('./agent/workflow');
const security  = require('./security/privacy');
const { startWebhookServer } = require('./webhook');
const { startChatServer }    = require('./chat/server');
const { runWatchdog, autoRepair } = require('./watchdog/watchdog');

const MOCK_MODE = process.env.MOCK_MODE === 'true';

// ── Boot ──────────────────────────────────────────────────────────────────────
async function boot() {
  logger.info('');
  logger.info('████  OpenClaw v2.0  ████  Booting…');
  logger.info('');

  // 1. Security check
  const sec = security.runSecurityCheck();
  if (!sec.ok) sec.issues.forEach(i => logger.warn(`[Security] ${i}`));
  await security.audit('boot', { version: '2.0', mockMode: MOCK_MODE });

  // 2. Watchdog health check + auto-repair
  await autoRepair();
  const { ok: healthy } = await runWatchdog();
  if (!healthy && !MOCK_MODE) {
    logger.error('[Boot] Critical issues detected — check logs. Continuing in degraded mode.');
  }

  // 3. Check Ollama brain
  const brainOk = await brain.isAvailable();
  if (brainOk) {
    const models = await brain.listModels();
    logger.info(`[Boot] 🧠 Ollama online — models: ${models.join(', ') || 'none pulled'}`);
    if (!models.includes(process.env.OLLAMA_MODEL || 'llama3')) {
      logger.warn(`[Boot] Model "${process.env.OLLAMA_MODEL || 'llama3'}" not found. Run: ollama pull ${process.env.OLLAMA_MODEL || 'llama3'}`);
    }
  } else {
    logger.warn('[Boot] ⚠️  Ollama not available — running without AI brain. Start with: ollama serve');
  }

  // 4. Start servers
  startWebhookServer();
  startChatServer();

  // 5. Start agents
  proactive.onAlert((msg) => {
    logger.warn(`[Alert] ${msg}`);
    // Forward to WhatsApp notifier if configured
    notifyWhatsApp(msg).catch(() => {});
  });

  proactive.onAction(async (action) => {
    if (action.type === 'retry_call') {
      logger.info(`[Proactive] Retrying call for ${action.purpose}`);
      await callAndWait(action.purpose);
    }
  });

  proactive.start();
  improve.start();

  // 6. Restore in-progress state
  await resumeFromMemory();

  // 7. Start daily scheduler
  startScheduler();

  // 8. Heartbeat
  startHeartbeat();

  // 9. Record boot in long-term memory
  await ltm.addEpisode('boot', `OpenClaw v2.0 started (mock=${MOCK_MODE}, brain=${brainOk})`, ['system', 'boot'], 5);

  logger.info('');
  logger.info('[Boot] ✅ OpenClaw v2.0 is live!');
  logger.info(`[Boot] 💬 Chat UI: http://localhost:${process.env.CHAT_PORT || 3742}/chat`);
  logger.info(`[Boot] 🔗 Webhook: http://localhost:${process.env.WEBHOOK_PORT || 3741}`);
  logger.info(`[Boot] 🧠 Brain:   ${brainOk ? 'Ollama ✅' : 'Offline ⚠️'}`);
  logger.info('');
}

// ── Resume from persisted memory ──────────────────────────────────────────────
async function resumeFromMemory() {
  const mem = store.load();
  store.ensureTodayState(mem);

  logger.info(`[Resume] Date: ${mem.dailyState.date}`);
  logger.info(`[Resume] T1 received=${!!mem.dailyState.task1}  completed=${mem.dailyState.task1Completed}`);
  logger.info(`[Resume] T2 received=${!!mem.dailyState.task2}  completed=${mem.dailyState.task2Completed}`);

  if (mem.dailyState.task1 && !mem.dailyState.task1Completed) {
    logger.info('[Resume] Resuming Task 1…');
    await executeTask(mem.dailyState.task1, 'task1');
  }

  if (mem.dailyState.task1Completed && !mem.dailyState.task2 && !mem.dailyState.task2Completed) {
    logger.info('[Resume] T1 done, fetching T2…');
    await callAndWait('task2');
  }

  if (mem.dailyState.task2 && !mem.dailyState.task2Completed) {
    logger.info('[Resume] Resuming Task 2…');
    await executeTask(mem.dailyState.task2, 'task2');
  }
}

// ── Daily scheduler ────────────────────────────────────────────────────────────
function startScheduler() {
  cron.schedule('0 9 * * *', async () => {
    logger.info('[Scheduler] 09:00 — Initiating Task 1 call');
    const mem = store.load();
    store.ensureTodayState(mem);
    if (mem.dailyState.task1) {
      logger.info('[Scheduler] Task 1 already received today, skipping.');
      return;
    }
    await callAndWait('task1');
  }, { timezone: 'America/Jamaica' });

  // Run daily trends workflow every morning at 8:30 AM
  cron.schedule('30 8 * * *', async () => {
    logger.info('[Scheduler] 08:30 — Running daily trends workflow');
    try {
      await workflow.runBuiltIn('daily_trends');
    } catch (e) {
      logger.warn('[Scheduler] Trends workflow error:', e.message);
    }
  }, { timezone: 'America/Jamaica' });

  // Daily email report at 10 PM
  cron.schedule('0 22 * * *', async () => {
    logger.info('[Scheduler] 22:00 — Sending daily report');
    try {
      const mail = require('./agent/mail');
      await mail.sendDailySummary();
    } catch (e) {
      logger.warn('[Scheduler] Daily report error:', e.message);
    }
  }, { timezone: 'America/Jamaica' });

  logger.info('[Scheduler] Cron jobs registered (Jamaica time)');
}

// ── Call + wait for transcription ─────────────────────────────────────────────
async function callAndWait(purpose) {
  logger.info(`[Flow] Calling for ${purpose}…`);
  await security.audit('call_placed', { purpose });

  if (MOCK_MODE) {
    const mock = caller.mockCallForTask(purpose);
    await handleTaskReceived({ purpose, task: mock.task });
    return;
  }

  try {
    await caller.callForTask(purpose);
    logger.info(`[Flow] Call placed for ${purpose}. Waiting for webhook…`);
  } catch (err) {
    store.recordError(store.load(), err.message);
    logger.error(`[Flow] Call failed for ${purpose}: ${err.message}`);
    await ltm.addEpisode('call_failed', `${purpose}: ${err.message}`, ['error', 'call'], 8);

    // Self-heal
    const fix = await improve.selfHeal(`Call failed for ${purpose}: ${err.message}`);
    if (fix?.action === 'retry') {
      logger.info('[Flow] Self-heal suggests retry — will retry next window');
    }
  }
}

// ── Transcription webhook event ───────────────────────────────────────────────
process.on('openclaw:task-received', async ({ purpose, task }) => {
  await handleTaskReceived({ purpose, task });
});

async function handleTaskReceived({ purpose, task }) {
  if (!task || !task.trim()) {
    logger.warn(`[Flow] Empty task for ${purpose} — skipping`);
    return;
  }

  logger.info(`[Flow] Task received for ${purpose}: "${task}"`);
  await security.audit('task_received', { purpose, taskLength: task.length });
  await ltm.addEpisode('task_received', `${purpose}: ${task}`, ['task'], 8);

  // Use Ollama to enrich/plan the task before executing
  const brainOk = await brain.isAvailable();
  let enrichedTask = task;

  if (brainOk) {
    try {
      const context = await ltm.getContextSummary(task, 400);
      const plan    = await brain.plan(task, context);
      logger.info(`[Flow] Brain plan: ${plan.summary} — ${plan.steps.length} steps`);
      enrichedTask  = task; // keep original for execution, plan logged
      await ltm.addEpisode('task_planned', `${purpose} plan: ${JSON.stringify(plan).substring(0,200)}`, ['plan'], 6);
    } catch (e) {
      logger.warn('[Flow] Brain planning error — using raw task:', e.message);
    }
  }

  await executeTask(enrichedTask, purpose);

  if (purpose === 'task1') {
    logger.info('[Flow] T1 complete — calling for T2…');
    await callAndWait('task2');
  } else {
    logger.info('[Flow] T2 complete — all done for today! 🎉');
    await notifyWhatsApp(`✅ Both tasks complete for ${store.today()}`);

    // Trigger self-improvement reflection
    try {
      await improve.runReflection('daily');
    } catch (e) {
      logger.warn('[Flow] Post-task reflection error:', e.message);
    }
  }
}

async function executeTask(task, purpose) {
  const mem = store.load();
  try {
    await runner.runTask(task, purpose, mem);
    await security.audit('task_completed', { purpose });
    await ltm.recordPattern(task.substring(0, 50), true);
    await notifyWhatsApp(`✅ ${purpose.toUpperCase()} complete: ${task.substring(0, 80)}`);
  } catch (err) {
    store.recordError(store.load(), `runTask(${purpose}): ${err.message}`);
    logger.error(`[Flow] Task error (${purpose}): ${err.message}`);
    await ltm.recordPattern(task.substring(0, 50), false);
    await notifyWhatsApp(`❌ ${purpose.toUpperCase()} failed: ${err.message.substring(0, 80)}`);
  }
}

// ── WhatsApp notifications ─────────────────────────────────────────────────────
async function notifyWhatsApp(message) {
  if (!process.env.WHATSAPP_TO || !process.env.TWILIO_ACCOUNT_SID) return;
  try {
    const twilio = require('twilio');
    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    await client.messages.create({
      from: `whatsapp:${process.env.WHATSAPP_FROM || process.env.TWILIO_WHATSAPP_NUMBER}`,
      to:   `whatsapp:${process.env.WHATSAPP_TO}`,
      body: `[OpenClaw] ${message}`,
    });
    logger.info(`[WhatsApp] Sent: ${message.substring(0, 80)}`);
  } catch (e) {
    logger.warn(`[WhatsApp] Send failed: ${e.message}`);
  }
}

// ── Heartbeat ──────────────────────────────────────────────────────────────────
function startHeartbeat() {
  setInterval(async () => {
    const mem = store.load();
    store.heartbeat(mem);
    logger.info(`[Heartbeat] alive — T1=${mem.dailyState.task1Completed} T2=${mem.dailyState.task2Completed} | total=${mem.meta.totalTasksCompleted}`);
  }, 5 * 60 * 1000);
}

// ── Graceful shutdown ──────────────────────────────────────────────────────────
async function shutdown(signal) {
  logger.info(`[OpenClaw] Shutting down (${signal})`);
  await security.audit('shutdown', { signal });
  try { const b = require('./agent/browser'); await b.close(); } catch {}
  process.exit(0);
}

process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('uncaughtException', async (err) => {
  logger.error('[OpenClaw] Uncaught exception:', err);
  store.recordError(store.load(), `uncaughtException: ${err.message}`);
  await ltm.addEpisode('crash', `uncaughtException: ${err.message}`, ['error', 'crash'], 10);
});
process.on('unhandledRejection', (reason) => {
  logger.error('[OpenClaw] Unhandled rejection:', reason);
  store.recordError(store.load(), `unhandledRejection: ${String(reason)}`);
});

// ── Go ─────────────────────────────────────────────────────────────────────────
boot().catch(err => {
  console.error('FATAL boot error:', err);
  process.exit(1);
});
