# ─────────────────────────────────────────────────────────────
#  OpenClaw v2.0 — Windows PowerShell Setup & Run
#  Usage:  .\setup.ps1 [-Mock] [-ChatOnly] [-BrainTest]
#
#  First-time: allow scripts with:
#    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
# ─────────────────────────────────────────────────────────────

param(
    [switch]$Mock,
    [switch]$ChatOnly,
    [switch]$BrainTest
)

$Host.UI.RawUI.WindowTitle = "OpenClaw v2.0"

$GREEN  = "Green"
$YELLOW = "Yellow"
$RED    = "Red"
$CYAN   = "Cyan"

Write-Host ""
Write-Host " ██████╗ ██████╗ ███████╗███╗   ██╗ ██████╗██╗      █████╗ ██╗    ██╗" -ForegroundColor Green
Write-Host "██╔═══██╗██╔══██╗██╔════╝████╗  ██║██╔════╝██║     ██╔══██╗██║    ██║" -ForegroundColor Green
Write-Host "██║   ██║██████╔╝█████╗  ██╔██╗ ██║██║     ██║     ███████║██║ █╗ ██║" -ForegroundColor Green
Write-Host "██║   ██║██╔═══╝ ██╔══╝  ██║╚██╗██║██║     ██║     ██╔══██║██║███╗██║" -ForegroundColor Green
Write-Host "╚██████╔╝██║     ███████╗██║ ╚████║╚██████╗███████╗██║  ██║╚███╔███╔╝" -ForegroundColor Green
Write-Host " ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝" -ForegroundColor Green
Write-Host "  v2.0 — Ollama Brain · Memory · Proactive · Self-Improving · Chat" -ForegroundColor DarkGreen
Write-Host ""

# ── 1. Check Node.js ──────────────────────────────────────────
Write-Host "[1/5] Checking Node.js..." -ForegroundColor White
try {
    $nodeVer = node -v 2>&1
    $major   = [int]($nodeVer -replace 'v(\d+).*','$1')
    if ($major -lt 18) {
        Write-Host "  ⚠  Node.js $nodeVer detected — v18+ recommended" -ForegroundColor Yellow
    } else {
        Write-Host "  ✓  Node.js $nodeVer" -ForegroundColor Green
    }
} catch {
    Write-Host "  ✗  Node.js not found. Download from https://nodejs.org" -ForegroundColor Red
    Read-Host "Press Enter to exit"; exit 1
}

# ── 2. Install dependencies ───────────────────────────────────
Write-Host "[2/5] Installing dependencies..." -ForegroundColor White
npm install --silent
if ($LASTEXITCODE -ne 0) {
    Write-Host "  ✗  npm install failed" -ForegroundColor Red
    Read-Host "Press Enter to exit"; exit 1
}
Write-Host "  ✓  Dependencies installed" -ForegroundColor Green

# ── 3. Check .env ─────────────────────────────────────────────
Write-Host "[3/5] Checking .env configuration..." -ForegroundColor White
if (-not (Test-Path ".env")) {
    if (Test-Path ".env.example") {
        Copy-Item ".env.example" ".env"
        Write-Host "  ⚠  .env created from .env.example — fill in your credentials" -ForegroundColor Yellow
    } else {
        Write-Host "  ✗  .env file not found!" -ForegroundColor Red
        Read-Host "Press Enter to exit"; exit 1
    }
}

$envContent = Get-Content ".env" -Raw
$requiredKeys = @("TWILIO_ACCOUNT_SID","TWILIO_AUTH_TOKEN","TWILIO_PHONE_NUMBER","TASK_PHONE_NUMBER","WEBHOOK_BASE_URL")
$missing = 0

foreach ($key in $requiredKeys) {
    if ($envContent -match "^$key=(.+)$") {
        $val = $Matches[1].Trim()
        if ($val -like "your_*" -or $val -like "*XXXXXXXXXX*" -or $val -eq "") {
            Write-Host "  ✗  Placeholder not filled: $key" -ForegroundColor Red
            $missing++
        } else {
            Write-Host "  ✓  $key" -ForegroundColor Green
        }
    } else {
        Write-Host "  ✗  Missing: $key" -ForegroundColor Red
        $missing++
    }
}

if ($missing -gt 0) {
    Write-Host ""
    Write-Host "  Fix the above .env values then re-run .\setup.ps1" -ForegroundColor Red
    Read-Host "Press Enter to exit"; exit 1
}

# Optional: WhatsApp
if ($envContent -match "^WHATSAPP_TO=(\+[0-9]+)$") {
    Write-Host "  ✓  WHATSAPP_TO (notifications enabled)" -ForegroundColor Green
} else {
    Write-Host "  ⚠  WHATSAPP_TO not set — WhatsApp notifications disabled" -ForegroundColor Yellow
}

# ── 4. Check Ollama ───────────────────────────────────────────
Write-Host "[4/5] Checking Ollama brain (optional)..." -ForegroundColor White
try {
    $response = Invoke-WebRequest -Uri "http://localhost:11434/api/tags" -TimeoutSec 3 -ErrorAction Stop
    Write-Host "  ✓  Ollama is online" -ForegroundColor Green
} catch {
    Write-Host "  ⚠  Ollama not running — start with: ollama serve" -ForegroundColor Yellow
    Write-Host "     Download: https://ollama.com" -ForegroundColor DarkGray
}

# ── 5. Watchdog health check ──────────────────────────────────
Write-Host "[5/5] Running health check..." -ForegroundColor White
node watchdog\watchdog.js
Write-Host ""

Write-Host "════════════════════════════════════════" -ForegroundColor Green
Write-Host "  ✅ OpenClaw v2.0 Ready!" -ForegroundColor Green
Write-Host "════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  💬 Chat UI:  " -NoNewline; Write-Host "http://localhost:3742/chat" -ForegroundColor Cyan
Write-Host "  🧠 Brain:    " -NoNewline; Write-Host "ollama serve (if not running)" -ForegroundColor Cyan
Write-Host "  🔧 Brain test:" -NoNewline; Write-Host "node brain/test.js" -ForegroundColor Cyan
Write-Host ""

# ── Launch ─────────────────────────────────────────────────────
if ($Mock) {
    Write-Host "  Running in MOCK MODE (no real calls)`n" -ForegroundColor Yellow
    $env:MOCK_MODE = "true"
    node index.js
} elseif ($ChatOnly) {
    Write-Host "  Starting CLI chat...`n" -ForegroundColor Cyan
    node chat\cli.js
} elseif ($BrainTest) {
    Write-Host "  Running brain test...`n" -ForegroundColor Cyan
    node brain\test.js
} else {
    Write-Host "  Starting full agent...`n"
    node index.js
}
