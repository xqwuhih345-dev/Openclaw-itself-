/**
 * OpenClaw Caller
 * ───────────────
 * Places an outbound call to the task dispatcher number using Twilio.
 * Captures the spoken task via TwiML <Record> and returns a transcript.
 */

require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const twilio  = require('twilio');
const logger  = require('./logger');

const {
  TWILIO_ACCOUNT_SID,
  TWILIO_AUTH_TOKEN,
  TWILIO_PHONE_NUMBER,
  TASK_PHONE_NUMBER,
  WEBHOOK_BASE_URL,
} = process.env;

let client = null;

function getClient() {
  if (!client) {
    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN) {
      throw new Error('Twilio credentials not set in .env');
    }
    client = twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
  }
  return client;
}

/**
 * Place a call to the task number.
 * The TwiML webhook records the response and saves it to memory.
 *
 * @param {string} callPurpose  — 'task1' | 'task2'  (passed as query param to webhook)
 * @returns {object} Twilio call SID and status
 */
async function callForTask(callPurpose = 'task1') {
  const twClient = getClient();

  const webhookUrl = `${WEBHOOK_BASE_URL}/openclaw/twiml?purpose=${callPurpose}`;

  logger.info(`[Caller] Placing call to ${TASK_PHONE_NUMBER} for ${callPurpose} — webhook: ${webhookUrl}`);

  const call = await twClient.calls.create({
    to:   TASK_PHONE_NUMBER,
    from: TWILIO_PHONE_NUMBER,
    url:  webhookUrl,
    statusCallback: `${WEBHOOK_BASE_URL}/openclaw/call-status?purpose=${callPurpose}`,
    statusCallbackMethod: 'POST',
    statusCallbackEvent: ['completed', 'failed', 'no-answer', 'busy'],
    timeout: 60,
  });

  logger.info(`[Caller] Call initiated — SID: ${call.sid}`);
  return { sid: call.sid, status: call.status };
}

/**
 * Simulate a call in dev/test mode (no real call placed).
 * Returns a mocked task string.
 */
function mockCallForTask(callPurpose) {
  const tasks = {
    task1: 'Research top 5 trending YouTube topics for today',
    task2: 'Write a 500-word script for a YouTube Shorts video on topic #1',
  };
  logger.warn(`[Caller] MOCK MODE — simulating ${callPurpose}: "${tasks[callPurpose]}"`);
  return { sid: 'mock-sid', status: 'mock-completed', task: tasks[callPurpose] };
}

module.exports = { callForTask, mockCallForTask };
