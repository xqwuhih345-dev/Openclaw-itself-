/**
 * OpenClaw Logger — winston-backed, writes to console + daily log files
 */

const { createLogger, format, transports } = require('winston');
const path = require('path');
const fs   = require('fs-extra');

const LOG_DIR = path.join(__dirname, 'logs');
fs.ensureDirSync(LOG_DIR);

const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: format.combine(
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.errors({ stack: true }),
    format.printf(({ timestamp, level, message, stack }) => {
      return stack
        ? `[${timestamp}] ${level.toUpperCase()}: ${message}\n${stack}`
        : `[${timestamp}] ${level.toUpperCase()}: ${message}`;
    })
  ),
  transports: [
    new transports.Console({ colorize: true }),
    new transports.File({
      filename: path.join(LOG_DIR, 'openclaw.log'),
      maxsize: 5 * 1024 * 1024, // 5 MB
      maxFiles: 10,
      tailable: true,
    }),
    new transports.File({
      level: 'error',
      filename: path.join(LOG_DIR, 'openclaw-errors.log'),
      maxsize: 2 * 1024 * 1024,
      maxFiles: 5,
    }),
  ],
});

module.exports = logger;
