#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  OpenClaw v2.0 — One-Line Setup & Run
#  Usage:  bash setup.sh [--mock] [--chat-only] [--brain-test]
# ─────────────────────────────────────────────────────────────

set -e

BOLD="\033[1m"
GREEN="\033[0;32m"
CYAN="\033[0;36m"
YELLOW="\033[0;33m"
RED="\033[0;31m"
DIM="\033[2m"
RESET="\033[0m"

MODE="run"
for arg in "$@"; do
  case $arg in
    --mock)       MODE="mock" ;;
    --chat-only)  MODE="chat" ;;
    --brain-test) MODE="brain" ;;
  esac
done

echo -e "${BOLD}${GREEN}"
echo "  ██████╗ ██████╗ ███████╗███╗   ██╗ ██████╗██╗      █████╗ ██╗    ██╗"
echo " ██╔═══██╗██╔══██╗██╔════╝████╗  ██║██╔════╝██║     ██╔══██╗██║    ██║"
echo " ██║   ██║██████╔╝█████╗  ██╔██╗ ██║██║     ██║     ███████║██║ █╗ ██║"
echo " ██║   ██║██╔═══╝ ██╔══╝  ██║╚██╗██║██║     ██║     ██╔══██║██║███╗██║"
echo " ╚██████╔╝██║     ███████╗██║ ╚████║╚██████╗███████╗██║  ██║╚███╔███╔╝"
echo "  ╚═════╝ ╚═╝     ╚══════╝╚═╝  ╚═══╝ ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝"
echo -e "${RESET}${BOLD}  v2.0 — Ollama Brain · Memory · Proactive · Self-Improving · Browser · Chat${RESET}"
echo ""

# ── 1. Check Node.js ──────────────────────────────────────────
echo -e "${BOLD}[1/5] Checking Node.js...${RESET}"
if ! command -v node &>/dev/null; then
  echo -e "${RED}  ✗ Node.js not found. Install it from https://nodejs.org (v18+ recommended)${RESET}"
  exit 1
fi
NODE_VER=$(node -v)
MAJOR=$(echo "$NODE_VER" | sed 's/v\([0-9]*\).*/\1/')
if [ "$MAJOR" -lt 18 ]; then
  echo -e "${YELLOW}  ⚠ Node.js ${NODE_VER} detected — v18+ recommended${RESET}"
else
  echo -e "${GREEN}  ✓ Node.js ${NODE_VER}${RESET}"
fi

# ── 2. Install dependencies ───────────────────────────────────
echo -e "${BOLD}[2/5] Installing dependencies...${RESET}"
npm install --silent 2>/dev/null || npm install
echo -e "${GREEN}  ✓ Dependencies installed${RESET}"

# ── 3. Check .env ─────────────────────────────────────────────
echo -e "${BOLD}[3/5] Checking .env configuration...${RESET}"
if [ ! -f ".env" ]; then
  if [ -f ".env.example" ]; then
    cp .env.example .env
    echo -e "${YELLOW}  ⚠ .env created from .env.example — please fill in your credentials${RESET}"
  else
    echo -e "${RED}  ✗ .env file not found!${RESET}"
    exit 1
  fi
fi

MISSING=0
for KEY in TWILIO_ACCOUNT_SID TWILIO_AUTH_TOKEN TWILIO_PHONE_NUMBER TASK_PHONE_NUMBER WEBHOOK_BASE_URL; do
  VAL=$(grep "^${KEY}=" .env 2>/dev/null | cut -d'=' -f2-)
  if [ -z "$VAL" ] || echo "$VAL" | grep -qE "your_|XXXXXXXXXX"; then
    echo -e "${RED}  ✗ Missing or placeholder: ${KEY}${RESET}"
    MISSING=$((MISSING + 1))
  else
    echo -e "${GREEN}  ✓ ${KEY}${RESET}"
  fi
done

# Optional checks (warn, don't block)
WA_TO=$(grep "^WHATSAPP_TO=" .env 2>/dev/null | cut -d'=' -f2-)
if [ -z "$WA_TO" ] || echo "$WA_TO" | grep -q "your_"; then
  echo -e "${YELLOW}  ⚠ WHATSAPP_TO not set — WhatsApp notifications disabled${RESET}"
else
  echo -e "${GREEN}  ✓ WHATSAPP_TO (notifications enabled)${RESET}"
fi

OLLAMA_URL=$(grep "^OLLAMA_URL=" .env 2>/dev/null | cut -d'=' -f2-)
OLLAMA_URL="${OLLAMA_URL:-http://localhost:11434}"
if curl -sf "${OLLAMA_URL}/api/tags" > /dev/null 2>&1; then
  echo -e "${GREEN}  ✓ Ollama brain online at ${OLLAMA_URL}${RESET}"
else
  echo -e "${YELLOW}  ⚠ Ollama not running — start with: ollama serve (optional)${RESET}"
fi

if [ "$MISSING" -gt 0 ]; then
  echo ""
  echo -e "${RED}  Fix the above .env values then re-run: bash setup.sh${RESET}"
  exit 1
fi

# ── 4. Security check ─────────────────────────────────────────
echo -e "${BOLD}[4/5] Security check...${RESET}"
chmod 600 .env 2>/dev/null && echo -e "${GREEN}  ✓ .env permissions set to 600${RESET}" || true

# Ensure .env in .gitignore
if [ -f "../.gitignore" ]; then
  if ! grep -q "\.env" ../.gitignore; then
    echo ".env" >> ../.gitignore
    echo -e "${GREEN}  ✓ Added .env to .gitignore${RESET}"
  else
    echo -e "${GREEN}  ✓ .env in .gitignore${RESET}"
  fi
fi

# ── 5. Watchdog health check ──────────────────────────────────
echo -e "${BOLD}[5/5] Running health check...${RESET}"
node watchdog/watchdog.js 2>/dev/null && echo -e "${GREEN}  ✓ Health check passed${RESET}" || {
  echo -e "${YELLOW}  ⚠ Health check had warnings — check output above${RESET}"
}

# ── Launch ─────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}════════════════════════════════════════${RESET}"
echo -e "${GREEN}${BOLD}  ✅ OpenClaw v2.0 Ready!${RESET}"
echo -e "${GREEN}${BOLD}════════════════════════════════════════${RESET}"
echo ""

CHAT_PORT=$(grep "^CHAT_PORT=" .env 2>/dev/null | cut -d'=' -f2-)
CHAT_PORT="${CHAT_PORT:-3742}"

echo -e "  💬 Chat UI:   ${CYAN}http://localhost:${CHAT_PORT}/chat${RESET}"
echo -e "  🧠 Brain:     ${CYAN}ollama serve${RESET} (if not running)"
echo -e "  🔧 Brain test:${CYAN}node brain/test.js${RESET}"
echo -e "  📊 Memory:    ${CYAN}npm run memory:view${RESET}"
echo -e "  🔍 Health:    ${CYAN}npm run health${RESET}"
echo ""

case $MODE in
  mock)
    echo -e "${YELLOW}  Running in MOCK MODE (no real calls)${RESET}\n"
    MOCK_MODE=true node index.js
    ;;
  chat)
    echo -e "${CYAN}  Starting CLI chat only…${RESET}\n"
    node chat/cli.js
    ;;
  brain)
    echo -e "${CYAN}  Running brain test…${RESET}\n"
    node brain/test.js
    ;;
  *)
    echo -e "  Starting full agent…\n"
    node index.js
    ;;
esac
