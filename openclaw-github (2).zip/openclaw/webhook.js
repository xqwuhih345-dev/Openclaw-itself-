/**
 * OpenClaw Webhook Server
 * ────────────────────────
 * Handles Twilio TwiML callbacks so OpenClaw can:
 *   1. Greet the dispatcher and say "ready for task"
 *   2. Record the spoken task response
 *   3. Receive the call-status callback and persist the task to memory
 *
 * Start alongside index.js — it shares the same process.
 */

require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const http    = require('http');
const url     = require('url');
const store   = require('./memory/store');
const logger  = require('./logger');

const PORT = process.env.WEBHOOK_PORT || 3741;

function parsePurpose(queryStr) {
  const q = new URLSearchParams(queryStr);
  return q.get('purpose') || 'task1';
}

function parseBody(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      const params = new URLSearchParams(body);
      const obj = {};
      for (const [k, v] of params.entries()) obj[k] = v;
      resolve(obj);
    });
  });
}

const server = http.createServer(async (req, res) => {
  const parsed  = url.parse(req.url, true);
  const pathname = parsed.pathname;
  const query   = parsed.query;

  // ── TwiML endpoint: Twilio calls this when the call connects ──────────────
  if (pathname === '/openclaw/twiml') {
    const purpose = query.purpose || 'task1';
    const taskNum = purpose === 'task2' ? 'second' : 'first';

    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice">Hello! OpenClaw is ready for the ${taskNum} task. Please state the task clearly after the beep.</Say>
  <Record
    action="${process.env.WEBHOOK_BASE_URL}/openclaw/recording-done?purpose=${purpose}"
    method="POST"
    maxLength="120"
    timeout="5"
    transcribe="true"
    transcribeCallback="${process.env.WEBHOOK_BASE_URL}/openclaw/transcription?purpose=${purpose}"
    playBeep="true"
  />
  <Say voice="alice">No recording received. Goodbye.</Say>
</Response>`;

    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(twiml);
    logger.info(`[Webhook] Served TwiML for ${purpose}`);
    return;
  }

  // ── Recording done callback ───────────────────────────────────────────────
  if (pathname === '/openclaw/recording-done') {
    const body    = await parseBody(req);
    const purpose = query.purpose || 'task1';
    logger.info(`[Webhook] Recording done for ${purpose} — URL: ${body.RecordingUrl}`);

    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(`<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="alice">Task received. Thank you.</Say><Hangup/></Response>`);
    return;
  }

  // ── Transcription callback ────────────────────────────────────────────────
  if (pathname === '/openclaw/transcription') {
    const body    = await parseBody(req);
    const purpose = query.purpose || 'task1';
    const text    = body.TranscriptionText || '';

    logger.info(`[Webhook] Transcription received for ${purpose}: "${text}"`);

    // Persist to memory
    const mem = store.load();
    store.ensureTodayState(mem);

    if (purpose === 'task1') {
      mem.dailyState.task1 = text;
      mem.dailyState.tasksReceivedToday = Math.max(mem.dailyState.tasksReceivedToday, 1);
    } else {
      mem.dailyState.task2 = text;
      mem.dailyState.tasksReceivedToday = 2;
    }
    store.save(mem);

    // Emit event so index.js can react
    process.emit('openclaw:task-received', { purpose, task: text });

    res.writeHead(200); res.end('OK');
    return;
  }

  // ── Call status callback ──────────────────────────────────────────────────
  if (pathname === '/openclaw/call-status') {
    const body    = await parseBody(req);
    const purpose = query.purpose || 'task1';
    logger.info(`[Webhook] Call status for ${purpose}: ${body.CallStatus}`);

    const mem = store.load();
    mem.dailyState.lastCallAttempt = new Date().toISOString();
    store.save(mem);

    if (['failed', 'busy', 'no-answer'].includes(body.CallStatus)) {
      store.recordError(mem, `Call ${purpose} ended with status: ${body.CallStatus}`);
    }

    res.writeHead(200); res.end('OK');
    return;
  }

  // ── Health ping ───────────────────────────────────────────────────────────
  if (pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', agent: 'openclaw', ts: new Date().toISOString() }));
    return;
  }

  res.writeHead(404); res.end('Not found');
});

function startWebhookServer() {
  server.listen(PORT, () => {
    logger.info(`[Webhook] Server listening on port ${PORT}`);
  });
}

module.exports = { startWebhookServer };
