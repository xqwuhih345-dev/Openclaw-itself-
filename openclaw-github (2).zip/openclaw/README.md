# ⚡ OpenClaw v2.0 — Autonomous Task Agent

> Local AI agent that calls a phone number to receive tasks, executes them autonomously, and never forgets.

---

## One-Line Install & Run

### 🐧 Linux / 🍎 macOS
```bash
git clone https://github.com/YOUR_USERNAME/openclaw.git && cd openclaw && bash setup.sh
```

### 🪟 Windows (PowerShell)
```powershell
git clone https://github.com/YOUR_USERNAME/openclaw.git; cd openclaw; .\setup.ps1
```

### 🪟 Windows (Command Prompt)
```cmd
git clone https://github.com/YOUR_USERNAME/openclaw.git && cd openclaw && setup.bat
```

### 📱 Android (Termux)
```bash
pkg install nodejs git && git clone https://github.com/YOUR_USERNAME/openclaw.git && cd openclaw && bash setup.sh
```

---

## Platform Support

| Platform | Supported | Setup Script |
|---|---|---|
| 🐧 Linux | ✅ Full | `bash setup.sh` |
| 🍎 macOS | ✅ Full | `bash setup.sh` |
| 🪟 Windows 10/11 | ✅ Full | `.\setup.ps1` or `setup.bat` |
| 📱 Android (Termux) | ✅ Core (no browser agent) | `bash setup.sh` |
| 📱 iPhone (iSH) | ⚠️ Limited | `bash setup.sh` |

> **Note:** The browser agent (Puppeteer) is not supported on mobile. All other features work.

---

## Run Modes

### Linux / macOS
```bash
bash setup.sh              # Full agent
bash setup.sh --mock       # Test — no real calls
bash setup.sh --chat-only  # CLI chat only
bash setup.sh --brain-test # Test Ollama connection
```

### Windows PowerShell
```powershell
.\setup.ps1              # Full agent
.\setup.ps1 -Mock        # Test — no real calls
.\setup.ps1 -ChatOnly    # CLI chat only
.\setup.ps1 -BrainTest   # Test Ollama connection
```

### Windows Command Prompt
```cmd
setup.bat           # Full agent
setup.bat mock      # Test — no real calls
setup.bat chat      # CLI chat only
setup.bat brain-test
```

---

## What It Does

1. **Calls** `+1 876 305-6193` every day at **9:00 AM** (Jamaica time)
2. **Receives** the first task via voice recording → transcription
3. **Executes** the task using its AI brain (Ollama)
4. **Calls again** after Task 1 is done to receive Task 2
5. **Remembers** everything across restarts via persistent memory
6. **Notifies** you on WhatsApp when tasks complete or fail
7. **Improves itself** daily/weekly via self-reflection

---

## Prerequisites

| Requirement | Notes |
|---|---|
| [Node.js v18+](https://nodejs.org) | Required on all platforms |
| [Ollama](https://ollama.com) | AI brain — Windows/Mac/Linux (not mobile) |
| [Twilio account](https://twilio.com) | For phone calls + WhatsApp |
| Gmail or SMTP | For email reports (optional) |

### Install Ollama + pull model

**Linux/macOS:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3
ollama pull nomic-embed-text   # optional — for semantic memory
ollama serve
```

**Windows:**
Download the installer from [ollama.com](https://ollama.com), then:
```powershell
ollama pull llama3
ollama serve
```

**Android (Termux) — Ollama not available:**
```bash
# OpenClaw will run without the AI brain in fallback mode
# All task scheduling, memory, and notifications still work
```

---

## Setup

### 1. Fill in your credentials

```bash
cp .env.example .env
# Edit .env with your values
```

**Windows:**
```powershell
Copy-Item .env.example .env
notepad .env
```

### 2. Required `.env` values

```env
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1XXXXXXXXXX
TASK_PHONE_NUMBER=+18763056193
WEBHOOK_BASE_URL=https://your-ngrok-url.ngrok.io
```

### 3. Expose your webhook (for local dev)

**Linux/macOS/Windows:**
```bash
# Install ngrok from https://ngrok.com
ngrok http 3741
# Copy the https:// URL → set as WEBHOOK_BASE_URL in .env
```

---

## Features

| Module | Description |
|---|---|
| 🧠 **Ollama Brain** | Local LLM — plans tasks, reflects, chats |
| 🗄 **Memory** | Short-term daily + long-term episodic with semantic search |
| 🤖 **Proactive Agent** | Monitors every 15 min, alerts on stuck tasks |
| 🔄 **Self-Improvement** | Daily/weekly reflection, auto-tunes config |
| 🌐 **Browser Agent** | Puppeteer — search, scrape, screenshot (desktop only) |
| 📧 **Mail Agent** | Task reports, daily digests, AI-composed emails |
| ⚙️ **Workflow Engine** | Chainable multi-step automations |
| 🔒 **Security** | AES-256-GCM encryption, audit log, rate limiting |
| 💬 **Chat UI** | Web UI + WebSocket + CLI chat |
| 📲 **WhatsApp** | Notifications via Twilio WhatsApp |

---

## Chat Interface

Once running, open your browser:
```
http://localhost:3742/chat
```

Or use the terminal chat:
```bash
npm run chat
```

Chat commands:
```
/status    — Today's task status
/memory    — Memory stats
/history   — Last 5 days
/help      — All commands
/exit      — Quit
```

---

## npm Scripts

```bash
npm start              # Start full agent
npm run chat           # CLI chat
npm run health         # Watchdog health check
npm run brain:test     # Test Ollama connection
npm run memory:view    # View full memory
npm run memory:clear   # Clear today's state
npm run memory:history # Task history
npm run workflow:run   # Run daily_trends workflow
```

---

## WhatsApp Setup

1. Join the [Twilio WhatsApp Sandbox](https://console.twilio.com/us1/develop/sms/try-it-out/whatsapp-learn)
2. Send `join <your-sandbox-word>` from WhatsApp to `+1 415 523 8886`
3. Set in `.env`:
```env
WHATSAPP_FROM=+14155238886
WHATSAPP_TO=+1YOURNUMBER
```

---

## Android (Termux) Setup

```bash
# 1. Install Termux from F-Droid (not Google Play)
# 2. Open Termux and run:
pkg update && pkg upgrade -y
pkg install nodejs git curl -y

# 3. Clone and run
git clone https://github.com/YOUR_USERNAME/openclaw.git
cd openclaw
bash setup.sh --mock   # test first without real calls
```

> Puppeteer (browser agent) is not available on Termux.
> All other features — memory, scheduling, WhatsApp, chat, mail — work fine.

---

## Project Structure

```
openclaw/
├── index.js              # Main entry point
├── setup.sh              # Linux/macOS one-liner
├── setup.bat             # Windows CMD one-liner
├── setup.ps1             # Windows PowerShell one-liner
├── .env.example          # Config template
│
├── brain/
│   ├── ollama.js         # Ollama LLM interface
│   ├── prompts.js        # System prompts
│   └── test.js           # Brain test
│
├── memory/
│   ├── store.js          # Short-term daily memory
│   ├── longTerm.js       # Long-term episodic memory
│   └── cli.js            # Memory CLI
│
├── agent/
│   ├── proactive.js      # Proactive monitoring
│   ├── selfImprove.js    # Self-improvement & reflection
│   ├── browser.js        # Puppeteer browser (desktop only)
│   ├── mail.js           # Email agent
│   └── workflow.js       # Workflow engine
│
├── chat/
│   ├── server.js         # Web UI + WebSocket server
│   └── cli.js            # Terminal chat
│
├── security/
│   └── privacy.js        # Encryption, audit, rate limiting
│
├── caller.js             # Twilio outbound call
├── webhook.js            # Twilio webhook receiver
├── taskRunner.js         # Task execution
├── logger.js             # Winston logger
│
└── watchdog/
    ├── watchdog.js       # Health checks + auto-repair
    └── health.js         # Standalone health reporter
```

---

## Pushing to GitHub

```bash
git init
git add .
git commit -m "OpenClaw v2.0"
git remote add origin https://github.com/YOUR_USERNAME/openclaw.git
git push -u origin main
```

Then anyone installs with:

**Linux/macOS/Android:**
```bash
git clone https://github.com/YOUR_USERNAME/openclaw.git && cd openclaw && bash setup.sh
```

**Windows:**
```powershell
git clone https://github.com/YOUR_USERNAME/openclaw.git; cd openclaw; .\setup.ps1
```

---

## License

MIT
